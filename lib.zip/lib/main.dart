import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


void main() async {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _cont = 0;
  bool _isRed = true;

  void increment() {
    setState(() {
      _cont++;
    });
  }

  void changeColor() {
    setState(() {
      _isRed = !_isRed;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 200,
        flexibleSpace: Container(
          color: Color.fromARGB(255, 2, 24, 224),
         
        ),
        backgroundColor: Colors.transparent,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(
          horizontal: 30,
          vertical: 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Align(
              alignment: Alignment.center,
              child: Text(
                'Ventas',
                textAlign: TextAlign.end,
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Color(0xff384B70),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),const TextField(
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 10,
                  ),
                  border: OutlineInputBorder(),
                 ),
            ),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Nombre del producto'),
            ),
            const SizedBox(
              height: 20,
            ),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  changeColor();
                },
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  backgroundColor: Color.fromARGB(255, 34, 253, 5),
                  padding: const EdgeInsets.symmetric(
                    vertical: 15,
                  ),
                  
                ),
                child: const Text('Buscar producto'),
              ),
            ),
            const Align(
              alignment: Alignment.centerLeft,
             
            ),
            const TextField(
              obscureText: true,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                ),
                border: OutlineInputBorder(),
                
              ),
            ),
            
            const SizedBox(
              height: 20,
            ),
            const SizedBox(
              height: 5,
            ),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  changeColor();
                },
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  backgroundColor: Color.fromARGB(255, 10, 192, 238),
                  padding: const EdgeInsets.symmetric(
                    vertical: 15,
                  ),
                  
                ),
                child: const Text('Pagar'),
              ),
            ),
            
          ],
        ),
      ),
    );
  }
}